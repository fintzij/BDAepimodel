library(testthat)
library(crayon)

test_check("crayon")
